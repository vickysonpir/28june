
module.exports = {
    publicPath : "http://10.44.126.73:4200/dist"
    , skin : ""
};
