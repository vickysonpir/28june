<?php
$HEADSTART_PATH = "../../";
$PIWIK_ENABLED = false;
$GA_ENABLED = false;
$WEBSITE_PATH = "http://localhost/linkedcat/";
$SNAPSHOT_PATH = $WEBSITE_PATH . "server/storage/";
?>