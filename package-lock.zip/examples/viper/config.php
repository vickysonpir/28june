<?php
$HEADSTART_PATH = "../../";
$PIWIK_ENABLED = false;
$GA_ENABLED = false;
$WEBSITE_PATH = "http://localhost/viper/";
$SNAPSHOT_PATH = $WEBSITE_PATH . "server/storage/";
$COOKIE_DOMAIN = "";
?>